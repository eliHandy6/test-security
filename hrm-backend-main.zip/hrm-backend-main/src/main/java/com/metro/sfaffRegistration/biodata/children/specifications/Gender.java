package com.metro.sfaffRegistration.biodata.children.specifications;

public enum Gender {
    MALE,
    FEMALE,
    PREFER_NOT_T0_SAY
}
