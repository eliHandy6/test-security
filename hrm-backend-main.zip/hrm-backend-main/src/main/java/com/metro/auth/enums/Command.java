package com.metro.auth.enums;

public enum Command {
    enable,
    disable
}
