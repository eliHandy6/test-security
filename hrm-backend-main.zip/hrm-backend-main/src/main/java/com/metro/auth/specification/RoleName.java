package com.metro.auth.specification;

public enum RoleName {

  ROLE_USER,
  ROLE_ADMIN
}
